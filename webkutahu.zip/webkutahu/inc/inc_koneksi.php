<?php
$host      = "localhost";
$user      = "root";
$pass      = "";
$db        = "webkutahu";

$koneksi   = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Gagal Terkoneksi");
}
