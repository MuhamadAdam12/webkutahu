<?php include("inc_header.php") ?>
<?php
$judul      = "";
$isi        = "";
$error      = "";
$sukses     = "";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    $id = "";
}
if ($id != "") {
    $sql1   = "select * from halaman where id = '$id'";
    $q1     = mysqli_query($koneksi, $sql1);
    $r1     = mysqli_fetch_array($q1);
    $judul  = $r1['judul'];
    $isi    = $r1['isi'];

    if ($isi == '') {
        $error  = "Data tidak ditemukan";
    }
}

if (isset($_POST['simpan'])) {
    $judul = $_POST['judul'];
    $isi   = $_POST['isi'];

    if ($judul == '' or $isi == '') {
        $error = "Silahkan masukan semua data yakni adalah data isi dan judul.";
    }

    if (empty($error)) {
        if ($id != "") {
            $sql1   = "update halaman set judul = '$judul',isi='$isi' where id = '$id' ";
        } else {
            $sql1       = "insert into halaman(judul,isi) values ('$judul','$isi')";
        }

        $q1       = mysqli_query($koneksi, $sql1);
        if ($q1) {
            $sukses    = "Sukses memasukan data";
        } else {
            $error     = "Kamu gagal memasukan data";
        }
    }
}
?>
<h1>halaman Admin input data></h1>
<div class="mb-3 row">
    <a href="halaman.php">
        << Kembali Ke Halaman Admin</a>
</div>
<?php
if ($error) {
?>
    <div class="alert alert-danger" role="alert">
        <?php echo $error ?>
    </div>
<?php
}
?>
<?php
if ($sukses) {
?>
    <div class="alert alert-primary" role="alert">
        <?php echo $sukses ?>
    </div>
<?php
}
?>
<form action="" method="post">
    <div class="mb-3 row">
        <label for="Judul" class="col-sm-2 col-form-label">Judul</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="Judul" value="<?php echo $judul ?>" name="judul">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="isi" class="col-sm-2 col-form-label">isi</label>
        <div class="col-sm-10">
            <textarea name="isi" class="form-control" id="summernote"><?php echo $isi ?></textarea>
        </div>
    </div>
    <div class="mb-3 row">
        <div class="col-sm-2"></div>
        <div class="col-sm-10">
            <input type="submit" name="simpan" value="Simpan Data" class="btn btn-primary" />
        </div>
    </div>
</form>
<?php include("inc_footer.php") ?>