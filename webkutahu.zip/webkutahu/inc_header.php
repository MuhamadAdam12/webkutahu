<?php
include_once("inc/inc_koneksi.php");
include_once("inc/inc_fungsi.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kutahu</title>
    <!-- SWIPER CSS-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <!-- CSS-->
    <link rel="stylesheet" href="css/style.css" />
</head>

<body>
    <nav>
        <div class="layar-dalam">
            <div class="logo">
                <a href=""><img src="asset/Kutahu Logo.png" class="putih" /></a>
                <a href=""><img src="asset/Kutahu Logo.png" class="hitam" /></a>
            </div>
            <div class="menu">
                <a href="#" class="tombol-menu">
                    <span class="garis"></span>
                    <span class="garis"></span>
                    <span class="garis"></span>
                </a>
                <ul>
                    <li><a href="#Beranda">Beranda</a></li>
                    <li><a href="#TentangKita">TentangKita</a></li>
                    <li><a href="#Pengaturan">Pengaturan</a></li>
                    <li><a href="#Gallery">Gallery</a></li>
                    <li><a href="#team">Team</a></li>
                    <li><a href="#Bantuan">Bantuan</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="layar-penuh">