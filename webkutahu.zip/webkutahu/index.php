<?php include_once("inc_header.php") ?>
<header id="Beranda">
    <div class="overlay"> </div>
    <video autoplay muted loop>
        <source src="asset/y2mate.com - Berpetualang dengan Keluarga  Little Angel Bahasa Indonesia  Kartun Anak Terbaru 2023_1080p.mp4" type="video/mp4" />
    </video>
    <div class="intro">
        <h3>HAYU READY</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi, officiis?</p>
        <p>
        </p>
    </div>
</header>
<main>
    <section id="TentangKita">
        <div class="layar-dalam">
            <h3>Tentang Kita</h3>
            <p class="ringkasan">Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati, cupiditate.</p>
            <div class="konten-isi">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sit, iure vero soluta exercitationem deleniti possimus cupiditate autem facilis magni illum?</p>
            </div>
        </div>
    </section>
    <section class="abuabu" id="Pengaturan">
        <div class="layar-dalam Pengaturan">
            <div>
                <img src="asset/SENYUM.png" />
                <h6>In Every Condition</h6>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ipsa illum recusandae nostrum. Obcaecati, quos vel.</p>
            </div>
            <div>
                <img src="asset/KELAUGRA.png" />
                <h6>Professional Team</h6>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem, ea voluptatem corporis molestias obcaecati deleniti.</p>
            </div>
            <div>
                <img src="asset/cERDAS.png" />
                <h6>Expert Hikers</h6>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem, ea voluptatem corporis molestias obcaecati deleniti.</p>
            </div>
        </div>
    </section>
    <section id="Gallery">
        <div class="swiper mySwiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="asset/foto1.jpg" alt="" />
                    <div>
                        <h2>VIDEO</h2>
                    </div>
                </div>
                <div class="swiper-slide">
                    <img src="asset/foto2.jpg" alt="" />
                    <div>
                        <h2>FOTO</h2>
                    </div>
                </div>
                <div class="swiper-slide">
                    <img src="asset/foto3.jpg" alt="" />
                    <div>
                        <h2>QUIZ</h2>
                    </div>
                </div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
        </div>
    </section>
    <section id="team">
        <div class="layar-dalam">
            <h3>Team</h3>
            <div class="tim">
                <div>
                    <img src="asset/gambar000.png" />
                    <h6>Malik</h6>
                    <span>Manajer Proyek</span>
                </div>
                <div>
                    <img src="asset/agi.jpeg" />
                    <h6>Agi</h6>
                    <span>Marketing</span>
                </div>
                <div>
                    <img src="asset/gambar000.png" />
                    <h6>Sarah</h6>
                    <span>Marketing</span>
                </div>
                <div>
                    <img src="asset/isti.jpeg" />
                    <h6>Nurani</h6>
                    <span>RND</span>
                </div>
                <div>
                    <img src="asset/ico.jpeg" />
                    <h6>Verico</h6>
                    <span>Keuangan</span>
                </div>
                <div>
                    <img src="asset/kosong3.jpeg" />
                    <h6>Adam</h6>
                    <span>Pengembangan</span>
                </div>
                <div>
                    <img src="asset/heru.jpg" />
                    <h6>Heru</h6>
                    <span>Design</span>
                </div>
                <div>
                    <img src="asset/gambar000.png" />
                    <h6>Kemal</h6>
                    <span>Pengujian</span>
                </div>
            </div>
        </div>
    </section>
    <?php include_once("inc_footer.php") ?>
</main>